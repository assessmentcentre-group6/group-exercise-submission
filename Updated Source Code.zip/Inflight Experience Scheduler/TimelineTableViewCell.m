//
//  TimelineTableViewCell.m
//  Inflight Experience Scheduler
//
//  Created by Watery Choi on 29/3/2017.
//  Copyright © 2017 Watery Choi. All rights reserved.
//

#import "TimelineTableViewCell.h"

@implementation TimelineTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

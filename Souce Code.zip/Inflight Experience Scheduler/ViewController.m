//
//  ViewController.m
//  Inflight Planner
//

#import "ViewController.h"
#import "TimelineTableViewCell.h"
#import "ProgrammeCollectionViewCell.h"

#define TIMELINE_CELL_RV @"timelineCell"
#define PROGRAMME_CELL_RV @"progCell"
#define PROGRAMME_LIST_COL 2
#define PROGRAMME_LIST_MARGIN 10
#define PROGRAMME_CELL_RATIO 1.1

@interface ViewController () <UITableViewDataSource, UITableViewDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UISearchBarDelegate>


@property (strong, nonatomic) IBOutlet UITableView *timelineList;
@property NSMutableArray<NSArray*> *timelineData;

@property (strong, nonatomic) IBOutlet UICollectionView *programmeList;
@property NSArray<NSString*> *programmes, *defaultProgrammes;
@property NSDictionary<NSString*,NSArray<NSString*>*> *programmeDatabase;

@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _timelineData=@[@[@"120",@"movie1"],@[@"120",@"movie2"]].mutableCopy;
    _defaultProgrammes=@[@"movie3",@"movie4",@"movie5"];
    _programmes=_defaultProgrammes;
    _programmeDatabase=@{@"movie1":@[@"Hang Over (Comedy)",@"movie1",@"120"],
                         @"movie2":@[@"We’re the Millers (Comedy)",@"movie2",@"120"],
                         @"movie3":@[@"Minions (Cartoon)",@"movie3",@"90"],
                         @"movie4":@[@"Monster University (Cartoon)",@"movie4",@"90"],
                         @"movie5":@[@"Sherlock (Comedy)",@"movie5",@"120"],
                         @"meal1":@[@"Chicken",@"meal1",@"60"],
                         @"meal2":@[@"Beef",@"meal2",@"60"],
                         @"meal3":@[@"Spaghetti",@"meal3",@"60"],
                         @"meal4":@[@"Rice",@"meal4",@"60"],
                         @"snack1":@[@"Noodle",@"snack1",@"30"],
                         @"snack2":@[@"Chocolate",@"snack2",@"30"],
                         @"snack3":@[@"Chip",@"snack3",@"30"],
                         @"snack4":@[@"Coke",@"snack4",@"30"],
                         @"snack5":@[@"Sprite",@"snack5",@"30"]};
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section==0) {
        if (_timelineData) {
            return _timelineData.count;
        }
    }
    return 0;
}
- (UIColor*)timelineHighColor { return [UIColor redColor]; }
- (UIColor*)timelineNilColor { return [UIColor colorWithWhite:1 alpha:0]; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==0) {
        TimelineTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:TIMELINE_CELL_RV];
        // [content appendFormat:@"%02d:%02d",(int)slice/2,(int)slice%2*30];

        NSArray *entry=(_timelineData?_timelineData[indexPath.row]:nil);
        if (entry) {
            NSString *key=entry.lastObject;
            NSArray<NSString*> *data=_programmeDatabase[key];
            [cell.lbTitle setText:data.firstObject];
            [cell.iv setImage:[UIImage imageNamed:data[1]]];
        }
        [cell.lbTime setText:[NSString stringWithFormat:@"%@",@(indexPath.row+1)]];
        [cell.lbTime.layer setCornerRadius:CGRectGetWidth(cell.lbTime.bounds)/2];

        return cell;
    } else return nil;
}

- (IBAction)dismissSearch:(id)sender {
    [_searchBar endEditing:YES];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section==0) return _programmes.count;
    else return 0;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==0) {
        ProgrammeCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:PROGRAMME_CELL_RV forIndexPath:indexPath];
        NSArray<NSString*> *data=_programmeDatabase[_programmes[indexPath.row]];
        [cell.lbTitle setText:data.firstObject];
        [cell.imageView setImage:[UIImage imageNamed:data[1]]];
        return cell;
    } else return 0;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {
    CGFloat w=(CGRectGetWidth(collectionView.bounds)-PROGRAMME_LIST_MARGIN*(PROGRAMME_LIST_COL+1))/PROGRAMME_LIST_COL;
    return CGSizeMake(w,w/PROGRAMME_CELL_RATIO);
}
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath { return YES; }
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [collectionView deselectItemAtIndexPath:indexPath animated:NO];
    NSString *entry=_programmes[indexPath.row];
    if (entry) {
        NSArray<NSString*> *data=_programmeDatabase[entry];
        [_timelineData addObject:@[data[2],entry]];
        [_timelineList reloadData];
    }
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    if (searchText.length>0) {
        NSMutableArray<NSString*> *newP=[NSMutableArray array];
        for (NSString *entry in _programmeDatabase.allKeys) {
            NSArray<NSString*> *data=_programmeDatabase[entry];
            if (data) {
                if ([data.firstObject containsString:searchText]) {
                    [newP addObject:entry];
                }
            }
        }
        _programmes=newP;
    } else {
        _programmes=_defaultProgrammes;
    }
    [_programmeList reloadData];
}

@end

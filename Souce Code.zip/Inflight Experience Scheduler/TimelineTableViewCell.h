//
//  TimelineTableViewCell.h
//  Inflight Experience Scheduler
//
//  Created by Watery Choi on 29/3/2017.
//  Copyright © 2017 Watery Choi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimelineTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lbTime;
@property (strong, nonatomic) IBOutlet UILabel *lbTitle;
@property (strong, nonatomic) IBOutlet UIImageView *iv;

@end
